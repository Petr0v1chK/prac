<?php
$page_title = "Настройки профиля";
require_once __DIR__ . '/../includes/header.php';

// Проверка авторизации
if (!isset($_SESSION['login'])) {
    header("Location: /login.php");
    exit;
}

// Получаем текущие данные пользователя
$login = $connect->real_escape_string($_SESSION['login']);
$user = $connect->query("SELECT * FROM user WHERE login = '$login'")->fetch_assoc();

if (!$user) {
    header("Location: /login.php");
    exit;
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="display-5 fw-bold text-primary mb-4">Настройки профиля</h1>
            <hr class="mb-5" style="border-top: 4px solid #0033a0; width: 90px;">

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-body p-5">
                    <form action="/admin/controllers/profile_update.php" method="POST">
                        <!-- Фамилия, Имя, Отчество -->
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Фамилия</label>
                                <input type="text" name="surname" class="form-control form-control-lg"
                                       value="<?= htmlspecialchars($user['surname']) ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Имя</label>
                                <input type="text" name="name" class="form-control form-control-lg"
                                       value="<?= htmlspecialchars($user['name']) ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Отчество</label>
                                <input type="text" name="patronymic" class="form-control form-control-lg"
                                       value="<?= htmlspecialchars($user['patronymic']) ?>">
                            </div>
                        </div>

                        <!-- Телефон -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Телефон</label>
                            <input type="tel" name="phone" class="form-control form-control-lg"
                                   value="<?= htmlspecialchars($user['phone']) ?>" required>
                        </div>

                        <!-- Email -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" class="form-control form-control-lg"
                                   value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>

                        <hr class="my-4">

                        <!-- Смена пароля -->
                        <h5 class="fw-bold text-primary mb-3">Сменить пароль</h5>
                        <div class="mb-3">
                            <label class="form-label">Новый пароль (оставьте пустым, если не хотите менять)</label>
                            <input type="password" name="new_password" class="form-control form-control-lg"
                                   placeholder="Введите новый пароль">
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Подтвердите новый пароль</label>
                            <input type="password" name="confirm_password" class="form-control form-control-lg"
                                   placeholder="Повторите новый пароль">
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-100 py-3 fw-bold">
                            Сохранить изменения
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>