<?php
?>
    <footer class="bg-dark text-light py-5 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p class="mb-2">
                        © 2022–<?= date("Y") ?> АО «Каменск-Уральский металлургический завод» (АО КУМЗ)
                    </p>
                    <p class="mb-2 small">
                        623405, Свердловская обл., г. Каменск-Уральский, ул. Заводская, 5<br>
                        Телефон: <a href="tel:+73439395300" class="text-light text-decoration-none">+7 (3439) 39-53-00</a> | 
                        Email: <a href="mailto:any@kumz.ru" class="text-light text-decoration-none">any@kumz.ru</a>
                    </p>
                    <p class="mb-2 small">
                        ОГРН 1026600934056 • ИНН 6669005000
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>