<?php
$page_title = "Поставщикам";
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <h1 class="display-5 fw-bold text-primary mb-4">Поставщикам</h1>
            <hr class="mb-5" style="border-top: 4px solid #0033a0; width: 90px;">

            <p class="lead text-center mb-5">АО «Каменск-Уральский металлургический завод» приглашает к сотрудничеству надежных поставщиков.</p>

            <!-- Блок "Поставщикам лома" -->
            <div class="card mb-4 shadow-sm">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-auto pe-4">
                            <span style="font-size: 3rem;">♻️</span>
                        </div>
                        <div class="col">
                            <h4 class="fw-bold">Поставщикам лома</h4>
                            <p class="mb-0">Мы регулярно закупаем алюминиевый и магниевый лом, отходы производства и вторичные ресурсы.</p>
                            <a href="#" class="btn btn-outline-primary mt-3">Подробнее о условиях закупки лома →</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Карточки -->
            <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
                <div class="col">
                    <div class="card h-100 text-center shadow-sm border-0">
                        <div class="card-body d-flex flex-column">
                            <div class="mb-3" style="font-size: 3.5rem;">📦</div>
                            <h5 class="fw-bold">Приобретение вспомогательных материалов и комплектующих</h5>
                            <a href="#" class="btn btn-outline-primary mt-auto">Перейти →</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100 text-center shadow-sm border-0">
                        <div class="card-body d-flex flex-column">
                            <div class="mb-3" style="font-size: 3.5rem;">📄</div>
                            <h5 class="fw-bold">Типовые формы договоры</h5>
                            <a href="#" class="btn btn-outline-primary mt-auto">Скачать →</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100 text-center shadow-sm border-0">
                        <div class="card-body d-flex flex-column">
                            <div class="mb-3" style="font-size: 3.5rem;">📋</div>
                            <h5 class="fw-bold">Регламенты, положения компании в области закупок</h5>
                            <a href="#" class="btn btn-outline-primary mt-auto">Перейти →</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- FAQ и контакты -->
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex align-items-center mb-3">
                                <span style="font-size: 2.5rem;">❓</span>
                                <h4 class="fw-bold ms-3 mb-0">FAQ</h4>
                            </div>
                            <p>Часто задаваемые вопросы по сотрудничеству с нами</p>
                            <a href="#" class="btn btn-outline-primary mt-auto">Перейти в раздел FAQ →</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <span style="font-size: 2.5rem;">📞</span>
                                <h4 class="fw-bold ms-3 mb-0">Контакты службы снабжения</h4>
                            </div>
                            <ul class="list-unstyled">
                                <li class="mb-2"><strong>Телефон:</strong> +7 (3439) 39-51-16</li>
                                <li class="mb-2"><strong>Email:</strong> zakupki@kumz.ru</li>
                                <li><strong>Режим работы:</strong> Пн–Пт с 08:00 до 17:00</li>
                            </ul>
                            <a href="/obratnaya-svyaz.php" class="btn btn-primary w-100 mt-3">Написать в службу снабжения</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>