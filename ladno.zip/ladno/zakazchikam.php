<?php
$page_title = "Заказчикам";
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-11">

            <h1 class="display-5 fw-bold text-primary mb-4 text-center">Заказчикам</h1>
            <hr class="mb-5 mx-auto" style="border-top: 4px solid #0033a0; width: 90px;">

            <p class="lead text-center mb-5">
                АО «Каменск-Уральский металлургический завод» предлагает широкий ассортимент высокотехнологичной продукции 
                из алюминиевых и магниевых сплавов.
            </p>

            <div class="row g-4">

                <!-- Карточка 1: Продукция в наличии -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm border-0 text-center">
                        <div class="card-body p-4">
                            <img src="/assets/images/product-stock.jpg" 
                                 class="img-fluid rounded mb-4" alt="Продукция в наличии" 
                                 style="height: 180px; object-fit: cover;">
                            <h5 class="fw-bold">Продукция в наличии</h5>
                            <p class="text-muted small mt-2">Актуальный складской остаток алюминиевого проката</p>
                            <a href="#" class="btn btn-outline-primary w-100 mt-3">Смотреть наличие →</a>
                        </div>
                    </div>
                </div>

                <!-- Карточка 2: Сертификаты -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm border-0 text-center">
                        <div class="card-body p-4">
                            <img src="/assets/images/certificates.jpg" 
                                 class="img-fluid rounded mb-4" alt="Сертификаты" 
                                 style="height: 180px; object-fit: cover;">
                            <h5 class="fw-bold">Сертификаты</h5>
                            <p class="text-muted small mt-2">Качество подтверждено международными и российскими сертификатами</p>
                            <a href="#" class="btn btn-outline-primary w-100 mt-3">Скачать сертификаты →</a>
                        </div>
                    </div>
                </div>

                <!-- Карточка 3: Листы для анодирования -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm border-0 text-center">
                        <div class="card-body p-4">
                            <img src="/assets/images/anodizing.jpg" 
                                 class="img-fluid rounded mb-4" alt="Листы для анодирования" 
                                 style="height: 180px; object-fit: cover;">
                            <h5 class="fw-bold">Листы для анодирования</h5>
                            <p class="text-muted small mt-2">Высококачественные листы с отличной поверхностью</p>
                            <a href="#" class="btn btn-outline-primary w-100 mt-3">Подробнее →</a>
                        </div>
                    </div>
                </div>

                <!-- Карточка 4: Листы для судостроения -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm border-0 text-center">
                        <div class="card-body p-4">
                            <img src="/assets/images/shipbuilding.jpg" 
                                 class="img-fluid rounded mb-4" alt="Листы для судостроения" 
                                 style="height: 180px; object-fit: cover;">
                            <h5 class="fw-bold">Листы для судостроения</h5>
                            <p class="text-muted small mt-2">Морские и речные сплавы повышенной коррозионной стойкости</p>
                            <a href="#" class="btn btn-outline-primary w-100 mt-3">Подробнее →</a>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Блок с призывом к действию -->
            <div class="text-center mt-5 pt-4 border-top">
                <h4 class="fw-bold text-primary">Хотите сделать заказ или получить консультацию?</h4>
                <p class="lead mt-3">Наши специалисты помогут подобрать оптимальную продукцию под ваши задачи.</p>
                <div class="mt-4">
                    <a href="/obratnaya-svyaz.php" class="btn btn-primary btn-lg px-5">Связаться с менеджером</a>
                    <a href="/application/" class="btn btn-outline-primary btn-lg px-5 ms-3">Подать заявку</a>
                </div>
            </div>

        </div>
    </div>
</div>

<?php 
require_once __DIR__ . '/includes/footer.php'; 
?>