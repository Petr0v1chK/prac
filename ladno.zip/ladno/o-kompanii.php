<?php
$page_title = "Главная";
require_once __DIR__ . '/includes/header.php';
?>

<!-- Герой-блок -->
<div class="hero text-white text-center">
    <div class="container">
        <h1 class="display-4 fw-bold mb-4">Каменск-Уральский металлургический завод</h1>
        <p class="lead fs-4 mb-0">Производство высокотехнологичной продукции из алюминиевых и магниевых сплавов</p>
    </div>
</div>

<!-- Блок "О компании" в стиле kumz.ru -->
<div class="container py-5">
    <div class="row justify-content-center mb-5">
        <div class="col-lg-10">
            <div class="card border-0 shadow">
                <div class="card-body p-4 p-md-5">
                    <div class="row align-items-center">
                        <!-- Текстовая часть -->
                        <div class="col-lg-7">
                            <h2 class="fw-bold text-primary mb-4">КУМЗ — надёжный партнёр для Вашего бизнеса</h2>
                            <p class="lead mb-4">Ведущий поставщик высокотехнологичной продукции из алюминиевых сплавов. Многопрофильное производство, в рамках которого выпускается продукция более 70 тыс. наименований из 150 алюминиевых и магниевых сплавов.</p>
                            <p>Акционерное общество «Каменск-Уральский металлургический завод» (АО «КУМЗ») является традиционным поставщиком изделий из алюминия, алюминиевых и магниевых сплавов. Завод основан в 1944 году и сегодня входит в число ведущих предприятий цветной металлургии России.</p>
                            <a href="/o-kompanii.php" class="btn btn-primary btn-lg mt-3">Подробнее о компании</a>
                        </div>
                        <!-- Цифровой блок -->
                        <div class="col-lg-5 mt-4 mt-lg-0">
                            <div class="row g-3">
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">1944</div>
                                        <small class="text-muted">год основания</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">3500+</div>
                                        <small class="text-muted">сотрудников</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">$800 млн</div>
                                        <small class="text-muted">инвестиций за 10 лет</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">Nadcap</div>
                                        <small class="text-muted">международная сертификация</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Остальной контент главной страницы (карточки разделов) -->
<div class="container py-5">
    <div class="row g-4">
        <!-- ... существующие карточки ... -->
    </div>
</div>

<?php 
require_once __DIR__ . '/includes/footer.php'; 
?>