<?php
session_start();
include "../../includes/connect.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: /profile/settings.php");
    exit;
}

// Проверка авторизации
if (!isset($_SESSION['login'])) {
    header("Location: /login.php");
    exit;
}

$login = $connect->real_escape_string($_SESSION['login']);

// Получаем текущего пользователя
$user = $connect->query("SELECT id_user FROM user WHERE login = '$login'")->fetch_assoc();
if (!$user) {
    header("Location: /login.php");
    exit;
}

$id_user = $user['id_user'];

// Собираем данные
$surname    = $connect->real_escape_string(trim($_POST['surname'] ?? ''));
$name       = $connect->real_escape_string(trim($_POST['name'] ?? ''));
$patronymic = $connect->real_escape_string(trim($_POST['patronymic'] ?? ''));
$phone      = $connect->real_escape_string(trim($_POST['phone'] ?? ''));
$email      = $connect->real_escape_string(trim($_POST['email'] ?? ''));
$new_password = $_POST['new_password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';

// Валидация обязательных полей
if (empty($surname) || empty($name) || empty($phone) || empty($email)) {
    header("Location: /profile/settings.php?error=Заполните+обязательные+поля");
    exit;
}

// Проверка email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: /profile/settings.php?error=Некорректный+email");
    exit;
}

// Обновление основных данных
$sql = "UPDATE user SET 
        surname = '$surname',
        name = '$name',
        patronymic = '$patronymic',
        phone = '$phone',
        email = '$email'
        WHERE id_user = $id_user";

// Если введён новый пароль
if (!empty($new_password)) {
    if ($new_password !== $confirm_password) {
        header("Location: /profile/settings.php?error=Пароли+не+совпадают");
        exit;
    }
    if (strlen($new_password) < 6) {
        header("Location: /profile/settings.php?error=Пароль+должен+быть+не+менее+6+символов");
        exit;
    }
    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $sql = "UPDATE user SET 
            surname = '$surname',
            name = '$name',
            patronymic = '$patronymic',
            phone = '$phone',
            email = '$email',
            password = '$hashed'
            WHERE id_user = $id_user";
}

if ($connect->query($sql)) {
    header("Location: /profile/settings.php?success=Профиль+успешно+обновлён");
} else {
    header("Location: /profile/settings.php?error=Ошибка+при+обновлении+профиля");
}
exit;