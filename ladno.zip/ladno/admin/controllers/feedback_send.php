<?php
include "../../includes/connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $surname = $connect->real_escape_string(trim($_POST['surname'] ?? ''));
    $name    = $connect->real_escape_string(trim($_POST['name'] ?? ''));
    $message = $connect->real_escape_string(trim($_POST['message'] ?? ''));
    $phone   = $connect->real_escape_string(trim($_POST['phone'] ?? ''));
    $email   = $connect->real_escape_string(trim($_POST['email'] ?? ''));
    
    if (empty($surname) || empty($name) || empty($message)) {
        header("Location: /obratnaya-svyaz.php?error=Заполните обязательные поля");
        exit;
    }
    
    $sql = "INSERT INTO feedback (surname, name, phone, email, message) 
            VALUES ('$surname', '$name', '$phone', '$email', '$message')";
    
    if ($connect->query($sql)) {
        header("Location: /obratnaya-svyaz.php?success=Сообщение успешно отправлено!");
        exit;
    } else {
        header("Location: /obratnaya-svyaz.php?error=Ошибка при отправке сообщения");
        exit;
    }
    
} else {
    header("Location: /obratnaya-svyaz.php");
    exit;
}
?>