<?php
header('Content-Type: application/json; charset=utf-8');

include "../../includes/connect.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    echo json_encode(['error' => 'ID не указан']);
    exit;
}

$res = $connect->query("SELECT * FROM news WHERE id_news = $id");

if (!$res || !$res->num_rows) {
    echo json_encode(['error' => 'Новость не найдена']);
    exit;
}

$news = $res->fetch_assoc();

// Проверяем существование изображения
$image = null;
if (!empty($news['image'])) {
    $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/news/' . $news['image'];
    if (file_exists($fullPath)) {
        $image = $news['image'];
    }
}

// Форматируем данные
echo json_encode([
    'title' => $news['title'],
    'date_formatted' => date('d.m.Y', strtotime($news['date'])),
    'text_formatted' => nl2br(htmlspecialchars($news['text'])),
    'text_raw' => $news['text'],
    'image' => $image,
    'created_at' => $news['created_at']
]);
?>