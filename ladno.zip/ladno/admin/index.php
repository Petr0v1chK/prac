<?php
include "../includes/header.php";
include "../function/function.php";

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
    header("Location: /login.php");
    exit;
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <h1 class="display-5 fw-bold text-primary mb-4">Панель администратора КУМЗ</h1>
            <hr class="mb-5" style="border-top: 4px solid #0033a0; width: 100px;">

            <!-- Красивые карточки управления -->
            <div class="row g-4 mb-5">
                <!-- Карточка управления новостями -->
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm border-0" style="transition: transform 0.3s, box-shadow 0.3s;">
                        <div class="card-body p-5 text-center">
                            <div class="mb-4">
                                <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #0033a0, #0055cc); border-radius: 20px; display: inline-flex; align-items: center; justify-content: center;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="white" viewBox="0 0 16 16">
                                        <path d="M0 2.5A1.5 1.5 0 0 1 1.5 1h11A1.5 1.5 0 0 1 14 2.5v10.528c0 .3-.05.654-.238.972h.738a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 1 1 0v9a1.5 1.5 0 0 1-1.5 1.5H1.497A1.497 1.497 0 0 1 0 13.5v-11zM12 14c.37 0 .654-.211.853-.441.092-.106.147-.279.147-.531V2.5a.5.5 0 0 0-.5-.5h-11a.5.5 0 0 0-.5.5v11c0 .278.223.5.497.5H12z"/>
                                        <path d="M2 3h10v2H2V3zm0 3h4v3H2V6zm0 4h4v1H2v-1zm0 2h4v1H2v-1zm5-6h2v1H7V6zm3 0h2v1h-2V6zM7 8h2v1H7V8zm3 0h2v1h-2V8zm-3 2h2v1H7v-1zm3 0h2v1h-2v-1zm-3 2h2v1H7v-1zm3 0h2v1h-2v-1z"/>
                                    </svg>
                                </div>
                            </div>
                            <h4 class="fw-bold mb-3" style="color: #0033a0;">Управление новостями</h4>
                            <p class="text-muted mb-4">Добавляйте, редактируйте и удаляйте новости компании</p>
                            <a href="/admin/news/" class="btn btn-lg px-5 py-3 fw-bold" 
                               style="background: linear-gradient(135deg, #0033a0, #0055cc); color: white; border: none; border-radius: 12px; transition: all 0.3s; box-shadow: 0 4px 15px rgba(0,51,160,0.3);">
                                Перейти к новостям →
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Карточка сообщений обратной связи -->
                <div class="col-md-6">
                    <div class="card h-100 shadow-sm border-0" style="transition: transform 0.3s, box-shadow 0.3s;">
                        <div class="card-body p-5 text-center">
                            <div class="mb-4">
                                <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #0066cc, #0088ff); border-radius: 20px; display: inline-flex; align-items: center; justify-content: center;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="white" viewBox="0 0 16 16">
                                        <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z"/>
                                        <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                                    </svg>
                                </div>
                            </div>
                            <h4 class="fw-bold mb-3" style="color: #0033a0;">Сообщения обратной связи</h4>
                            <p class="text-muted mb-4">Просматривайте сообщения от пользователей и клиентов</p>
                            <a href="/admin/controllers/feedback.php" class="btn btn-lg px-5 py-3 fw-bold" 
                               style="background: linear-gradient(135deg, #0066cc, #0088ff); color: white; border: none; border-radius: 12px; transition: all 0.3s; box-shadow: 0 4px 15px rgba(0,102,204,0.3);">
                                Просмотреть сообщения →
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Статистика (опционально) -->
            <div class="row g-4 mb-5">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm text-center p-4">
                        <div class="fs-1 mb-2" style="color: #0033a0;">📋</div>
                        <h5 class="fw-bold">Всего заявок</h5>
                        <span class="fs-4 fw-bold" style="color: #0033a0;">
                            <?= $connect->query("SELECT COUNT(*) as count FROM application")->fetch_assoc()['count'] ?? 0 ?>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm text-center p-4">
                        <div class="fs-1 mb-2" style="color: #0033a0;">📰</div>
                        <h5 class="fw-bold">Новостей</h5>
                        <span class="fs-4 fw-bold" style="color: #0033a0;">
                            <?= $connect->query("SELECT COUNT(*) as count FROM news")->fetch_assoc()['count'] ?? 0 ?>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm text-center p-4">
                        <div class="fs-1 mb-2" style="color: #0033a0;">💬</div>
                        <h5 class="fw-bold">Сообщений</h5>
                        <span class="fs-4 fw-bold" style="color: #0033a0;">
                            <?= $connect->query("SELECT COUNT(*) as count FROM feedback")->fetch_assoc()['count'] ?? 0 ?>
                        </span>
                    </div>
                </div>
            </div>

            <h4 class="mb-4">Все заявки клиентов</h4>

            <?= fnOutCardAdmin() ?>

        </div>
    </div>
</div>

<!-- Добавляем hover-эффекты -->
<style>
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 51, 160, 0.15) !important;
    }
    
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 51, 160, 0.4) !important;
    }
</style>

<?php include "../includes/footer.php"; ?>