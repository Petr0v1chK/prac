<?php
$page_title = "Главная";
require_once __DIR__ . '/includes/header.php';
?>

<!-- СЛАЙДЕР -->
<div class="hero-slider position-relative">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-inner">
            <div class="carousel-item active" style="background-image: url('/assets/images/slide1.jpg');"></div>
            <div class="carousel-item" style="background-image: url('/assets/images/slide2.jpg');"></div>
            <div class="carousel-item" style="background-image: url('/assets/images/slide3.jpg');"></div>
        </div>
    </div>
    <div class="hero-overlay text-white text-center position-absolute top-50 start-50 translate-middle w-100 px-3">
        <h1 class="display-4 fw-bold mb-4">Каменск-Уральский металлургический завод</h1>
        <p class="lead fs-4 mb-0">Производство высокотехнологичной продукции из алюминиевых и магниевых сплавов</p>
    </div>
</div>

<!-- ОСНОВНОЙ КОНТЕНТ -->
<div class="container py-5">
    <!-- Блок "О компании" (стиль kumz.ru) -->
    <div class="row justify-content-center mb-5">
        <div class="col-lg-10">
            <div class="card border-0 shadow">
                <div class="card-body p-4 p-md-5">
                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <h2 class="fw-bold text-primary mb-4">КУМЗ — надёжный партнёр для вашего бизнеса</h2>
                            <p class="lead mb-4">Ведущий поставщик высокотехнологичной продукции из алюминиевых сплавов. Многопрофильное производство, в рамках которого выпускается продукция более 70 тыс. наименований из 150 алюминиевых и магниевых сплавов. Инновационные материалы для авиастроения, морского и речного судостроения, прицепной техники.</p>
                            <a href="/o-kompanii.php" class="btn btn-primary btn-lg">Подробнее о компании</a>
                        </div>
                        <div class="col-lg-5 mt-4 mt-lg-0">
                            <div class="row g-3">
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">1944</div>
                                        <small class="text-muted">год основания</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">3500+</div>
                                        <small class="text-muted">сотрудников</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">$800 млн</div>
                                        <small class="text-muted">инвестиций за 10 лет</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="border rounded p-3 text-center bg-light">
                                        <div class="fs-2 fw-bold text-primary">Nadcap</div>
                                        <small class="text-muted">международная сертификация</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Карточки разделов -->
    <div class="row g-4">
        <!-- О компании -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">🏭</div>
                    <h5 class="fw-bold">О компании</h5>
                    <p class="text-muted small">АО «КУМЗ» — традиционный поставщик изделий из алюминия и магниевых сплавов. Год основания — 1944. Более 3500 сотрудников.</p>
                    <a href="/o-kompanii.php" class="btn btn-outline-primary btn-sm mt-2">Подробнее →</a>
                </div>
            </div>
        </div>
        <!-- Продукция -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">📦</div>
                    <h5 class="fw-bold">Продукция</h5>
                    <p class="text-muted small">Листы, плиты, профили, трубы, прутки, проволока, штамповки, поковки, теплообменники, гофролисты и многое другое.</p>
                    <a href="/zakazchikam.php" class="btn btn-outline-primary btn-sm mt-2">Каталог продукции →</a>
                </div>
            </div>
        </div>
        <!-- Преимущества -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">⭐</div>
                    <h5 class="fw-bold">Преимущества</h5>
                    <p class="text-muted small">Более $800 млн инвестиций в оборудование за 10 лет. Сертификация Nadcap, соответствие AS/EN 9100, ИСО 9001.</p>
                    <a href="/o-kompanii.php" class="btn btn-outline-primary btn-sm mt-2">Наши стандарты →</a>
                </div>
            </div>
        </div>
        <!-- Новости -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">📰</div>
                    <h5 class="fw-bold">Новости</h5>
                    <p class="text-muted small">Актуальные события завода: техническое переоснащение, новые разработки, участие в выставках, контракты и достижения.</p>
                    <a href="/novosti.php" class="btn btn-outline-primary btn-sm mt-2">Читать новости →</a>
                </div>
            </div>
        </div>
        <!-- Поставщикам -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">🤝</div>
                    <h5 class="fw-bold">Поставщикам</h5>
                    <p class="text-muted small">Закупка алюминиевого и магниевого лома, вспомогательных материалов. Типовые договоры и регламенты закупок.</p>
                    <a href="/postavshchikam.php" class="btn btn-outline-primary btn-sm mt-2">Условия сотрудничества →</a>
                </div>
            </div>
        </div>
        <!-- Заказчикам -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">🎯</div>
                    <h5 class="fw-bold">Заказчикам</h5>
                    <p class="text-muted small">Широкий ассортимент продукции, сертификаты качества, складская программа, специальные условия для постоянных клиентов.</p>
                    <a href="/zakazchikam.php" class="btn btn-outline-primary btn-sm mt-2">Информация для заказчиков →</a>
                </div>
            </div>
        </div>
        <!-- Обратная связь -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">💬</div>
                    <h5 class="fw-bold">Обратная связь</h5>
                    <p class="text-muted small">Задайте вопрос, оставьте предложение или запросите консультацию. Мы ответим в ближайшее время.</p>
                    <a href="/obratnaya-svyaz.php" class="btn btn-outline-primary btn-sm mt-2">Написать нам →</a>
                </div>
            </div>
        </div>
        <!-- Контакты -->
        <div class="col-md-6 col-lg-3">
            <div class="card h-100 shadow-sm border-0 text-center">
                <div class="card-body p-4">
                    <div class="mb-3" style="font-size: 3rem;">📞</div>
                    <h5 class="fw-bold">Контакты</h5>
                    <p class="text-muted small">623405, Свердловская обл., г. Каменск-Уральский, ул. Заводская, 5<br>Тел.: +7 (3439) 39-53-00<br>Email: any@kumz.ru</p>
                    <a href="/obratnaya-svyaz.php" class="btn btn-outline-primary btn-sm mt-2">Все контакты →</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- стили для слайдера (если не вынесены в style.css) -->
<style>
    .hero-slider { height: 500px; overflow: hidden; }
    .carousel-item { height: 500px; background-size: cover; background-position: center; position: relative; }
    .carousel-item::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 51, 160, 0.65); }
    .hero-overlay { z-index: 10; }
    .hero-overlay h1 { text-shadow: 0 4px 15px rgba(0,0,0,0.6); }
    @media (max-width: 768px) {
        .hero-slider, .carousel-item { height: 400px; }
    }
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>