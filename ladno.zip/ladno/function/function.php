<?php
include __DIR__ . "/../includes/connect.php";

// список продукции
function fnOutService() {
    global $connect;
    $res = $connect->query("SELECT * FROM service ORDER BY name");
    $out = "";
    while ($r = $res->fetch_assoc()) {
        $out .= "<option value='{$r['id_service']}'>{$r['name']}</option>";
    }
    return $out;
}

// заявки пользователя в личном кабинете
function fnOutCardProfile($login) {
    global $connect;
    
    $u = $connect->query("SELECT id_user FROM user WHERE login = '" . $connect->real_escape_string($login) . "'")->fetch_assoc();
    
    if (!$u) return "<p class='text-danger'>Пользователь не найден.</p>";

    $res = $connect->query("
        SELECT a.*, s.status, se.name AS sname 
        FROM application a
        JOIN status s ON a.id_status = s.id_status
        JOIN service se ON a.id_service = se.id_service
        WHERE a.id_user = {$u['id_user']}
        ORDER BY a.id_application DESC
    ");

    if (!$res->num_rows) {
        return "<p class='text-muted'>У вас пока нет заявок.</p>";
    }

    $out = "<div class='row row-cols-1 row-cols-md-2 g-4'>";
    while ($r = $res->fetch_assoc()) {
        $out .= "
        <div class='col'>
            <div class='card h-100 border-primary'>
                <div class='card-body'>
                    <h5 class='card-title text-primary'>Заявка №{$r['id_application']}</h5>
                    <p><strong>Продукция:</strong> {$r['sname']}</p>
                    <p><strong>Дата и время:</strong> {$r['date']} {$r['time']}</p>
                    <p><strong>Адрес:</strong> {$r['address']}</p>
                    <p><strong>Статус:</strong> <span class='badge bg-primary'>{$r['status']}</span></p>
                    " . (!empty($r['description']) ? "<p><strong>Комментарий:</strong><br>{$r['description']}</p>" : "") . "
                </div>
            </div>
        </div>";
    }
    $out .= "</div>";
    return $out;
}

// заявки для админа
function fnOutCardAdmin() {
    global $connect;
    
    $sql = "SELECT a.id_application, a.date, a.time, a.address, a.phone, a.description, 
                   u.name, u.surname, u.patronymic,
                   s.status, se.name AS sname
            FROM application a
            JOIN user u ON a.id_user = u.id_user
            JOIN status s ON a.id_status = s.id_status
            JOIN service se ON a.id_service = se.id_service
            ORDER BY a.id_application DESC";

    $result = $connect->query($sql);

    if (!$result->num_rows) {
        return "<h4 class='text-center text-muted py-5'>Заявок пока нет</h4>";
    }

    $out = "<div class='row row-cols-1 row-cols-md-2 g-4'>";

    while ($item = $result->fetch_assoc()) {
        $out .= "
        <div class='col'>
            <div class='card h-100'>
                <div class='card-body'>
                    <h5 class='card-title text-primary'>Заявка №{$item['id_application']}</h5>
                    <p><strong>Клиент:</strong> {$item['surname']} {$item['name']} {$item['patronymic']}</p>
                    <p><strong>Продукция:</strong> {$item['sname']}</p>
                    <p><strong>Дата и время:</strong> {$item['date']} {$item['time']}</p>
                    <p><strong>Адрес:</strong> {$item['address']}</p>
                    <p><strong>Телефон:</strong> {$item['phone']}</p>
                    <p><strong>Статус:</strong> <span class='badge bg-primary'>{$item['status']}</span></p>
                    " . (!empty($item['description']) ? "<p><strong>Комментарий:</strong><br>{$item['description']}</p>" : "") . "
                </div>
            </div>
        </div>";
    }
    $out .= "</div>";
    return $out;
}

// Вывод сообщений из формы "Обратная связь" для админа
function fnOutFeedbackAdmin() {
    global $connect;
    
    $sql = "SELECT * FROM feedback ORDER BY created_at DESC";
    $result = $connect->query($sql);

    if (!$result || !$result->num_rows) {
        return "<h4 class='text-center text-muted py-5'>Сообщений пока нет</h4>";
    }

    $out = "<div class='row row-cols-1 g-4'>";

    while ($item = $result->fetch_assoc()) {
        $out .= "
        <div class='col'>
            <div class='card border-primary shadow-sm'>
                <div class='card-body p-4'>
                    <div class='d-flex justify-content-between align-items-start mb-3'>
                        <h5 class='card-title text-primary mb-0'>Сообщение №{$item['id_feedback']}</h5>
                        <small class='text-muted'>" . date('d.m.Y H:i', strtotime($item['created_at'])) . "</small>
                    </div>
                    <p><strong>ФИО:</strong> {$item['surname']} {$item['name']}</p>
                    " . (!empty($item['phone']) ? "<p><strong>Телефон:</strong> {$item['phone']}</p>" : "") . "
                    " . (!empty($item['email']) ? "<p><strong>Email:</strong> {$item['email']}</p>" : "") . "
                    <div class='mt-3'>
                        <strong>Сообщение:</strong>
                        <div class='p-3 bg-light rounded mt-2'>
                            " . nl2br(htmlspecialchars($item['message'])) . "
                        </div>
                    </div>
                </div>
            </div>
        </div>";
    }
    $out .= "</div>";
    return $out;
}

// Вывод новостей на публичной странице (с фото и кнопкой "Подробнее" в модальном окне)
function fnOutNews() {
    global $connect;
    $res = $connect->query("SELECT * FROM news ORDER BY date DESC, id_news DESC");
    
    if (!$res->num_rows) {
        return "<p class='text-muted'>Новостей пока нет.</p>";
    }

    $out = "";
    while ($r = $res->fetch_assoc()) {
        // Проверяем, есть ли фото и существует ли файл
        $imgPath = '';
        if (!empty($r['image'])) {
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/news/' . $r['image'];
            if (file_exists($fullPath)) {
                $imgPath = '/assets/images/news/' . $r['image'];
            }
        }
        
        // Блок с изображением
        if ($imgPath) {
            $imgBlock = "<img src='{$imgPath}' class='news-image' alt='{$r['title']}'>";
        } else {
            // Заглушка с иконкой
            $imgBlock = "
            <div class='news-placeholder'>
                <svg xmlns='http://www.w3.org/2000/svg' width='64' height='64' fill='#0033a0' viewBox='0 0 16 16'>
                    <path d='M0 2.5A1.5 1.5 0 0 1 1.5 1h11A1.5 1.5 0 0 1 14 2.5v10.528c0 .3-.05.654-.238.972h.738a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 1 1 0v9a1.5 1.5 0 0 1-1.5 1.5H1.497A1.497 1.497 0 0 1 0 13.5v-11zM12 14c.37 0 .654-.211.853-.441.092-.106.147-.279.147-.531V2.5a.5.5 0 0 0-.5-.5h-11a.5.5 0 0 0-.5.5v11c0 .278.223.5.497.5H12z'/>
                    <path d='M2 3h10v2H2V3zm0 3h4v3H2V6zm0 4h4v1H2v-1zm0 2h4v1H2v-1zm5-6h2v1H7V6zm3 0h2v1h-2V6zM7 8h2v1H7V8zm3 0h2v1h-2V8zm-3 2h2v1H7v-1zm3 0h2v1h-2v-1zm-3 2h2v1H7v-1zm3 0h2v1h-2v-1z'/>
                </svg>
                <p class='text-muted mt-2'>Нет изображения</p>
            </div>";
        }

        // Обрезаем текст для превью (первые 300 символов)
        $previewText = mb_substr(strip_tags($r['text']), 0, 300) . '...';

        $out .= "
        <div class='news-card mb-4'>
            {$imgBlock}
            <div class='news-content'>
                <div class='d-flex justify-content-between align-items-start mb-2 flex-wrap'>
                    <h5 class='fw-bold me-3'>{$r['title']}</h5>
                    <span class='news-date'>" . date('d.m.Y', strtotime($r['date'])) . "</span>
                </div>
                <p class='news-text'>
                    " . nl2br(htmlspecialchars($previewText)) . "
                </p>
                <div class='mt-3'>
                    <button type='button' class='btn btn-primary' onclick='openNews({$r['id_news']})'>
                        Подробнее →
                    </button>
                </div>
            </div>
        </div>";
    }
    return $out;
}

// Вывод новостей для админа (с фото и кнопками)
function fnOutNewsAdmin() {
    global $connect;
    $res = $connect->query("SELECT * FROM news ORDER BY date DESC, id_news DESC");
    
    if (!$res->num_rows) {
        return "<h4 class='text-center text-muted py-5'>Новостей пока нет</h4>";
    }

    $out = "<div class='row row-cols-1 g-4'>";
    while ($r = $res->fetch_assoc()) {
        // Проверка изображения
        $imgBlock = '';
        if (!empty($r['image'])) {
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/news/' . $r['image'];
            if (file_exists($fullPath)) {
                $imgBlock = "<img src='/assets/images/news/{$r['image']}' class='img-fluid rounded mb-3' style='max-height: 200px; object-fit: cover;'>";
            } else {
                $imgBlock = "<div class='bg-light rounded mb-3 d-flex align-items-center justify-content-center' style='height: 200px;'><span class='text-muted'>Файл не найден</span></div>";
            }
        } else {
            $imgBlock = "<div class='bg-light rounded mb-3 d-flex align-items-center justify-content-center' style='height: 200px;'><span class='text-muted'>Без фото</span></div>";
        }

        $out .= "
        <div class='col'>
            <div class='card h-100'>
                <div class='card-body'>
                    {$imgBlock}
                    <div class='d-flex justify-content-between'>
                        <h5 class='card-title text-primary'>{$r['title']}</h5>
                        <span class='text-muted small'>" . date('d.m.Y', strtotime($r['date'])) . "</span>
                    </div>
                    <p class='card-text mt-2'>" . nl2br(htmlspecialchars(substr($r['text'], 0, 200))) . (strlen($r['text']) > 200 ? '...' : '') . "</p>
                    
                    <div class='mt-3'>
                        <a href='/admin/news/edit.php?id={$r['id_news']}' class='btn btn-warning btn-sm'>Редактировать</a>
                        <a href='/admin/controllers/news_delete.php?id={$r['id_news']}' 
                           class='btn btn-danger btn-sm' 
                           onclick=\"return confirm('Удалить новость?');\">Удалить</a>
                    </div>
                </div>
            </div>
        </div>";
    }
    $out .= "</div>";
    return $out;
}
?>