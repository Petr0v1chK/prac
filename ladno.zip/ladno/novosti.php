<?php
$page_title = "Новости";
require_once __DIR__ . '/includes/header.php';
include __DIR__ . '/function/function.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <div class="text-end mt-4">
                <a href="/admin/news/" class="btn btn-warning">
                    ✏️ Редактировать новости (админ)
                </a>
            </div>
        <?php endif; ?>

            <!-- Заголовок страницы -->
            <h1 class="display-5 fw-bold text-primary mb-4">Новости</h1>
            <hr class="mb-5" style="border-top: 3px solid #0033a0; width: 80px;">

            <div id="news-container">
                <?= fnOutNews() ?>
            </div>

        </div>
    </div>
</div>

<!-- Модальное окно для новости -->
<div class="modal fade" id="newsModal" tabindex="-1" aria-labelledby="newsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header" style="background: linear-gradient(135deg, #0033a0, #0055cc); color: white;">
                <h4 class="modal-title fw-bold" id="newsModalLabel">Новость</h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Закрыть"></button>
            </div>
            <div class="modal-body p-0">
                <!-- Скелетон-загрузка -->
                <div id="modal-loading" class="text-center py-5">
                    <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                        <span class="visually-hidden">Загрузка...</span>
                    </div>
                    <p class="mt-3 text-muted">Загрузка новости...</p>
                </div>
                
                <!-- Контент новости -->
                <div id="modal-content" style="display: none;">
                    <div class="modal-image-container">
                        <img id="modal-image" src="" class="modal-news-image" alt="Новость">
                    </div>
                    <div class="modal-news-body p-4 p-md-5">
                        <div class="d-flex justify-content-between align-items-start mb-4">
                            <h2 class="fw-bold text-primary" id="modal-title"></h2>
                            <span class="news-date-modal" id="modal-date"></span>
                        </div>
                        <div class="news-full-text" id="modal-text"></div>
                    </div>
                </div>
                
                <!-- Ошибка загрузки -->
                <div id="modal-error" class="text-center py-5" style="display: none;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="#dc3545" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                        <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                    </svg>
                    <h5 class="mt-3 text-danger">Ошибка загрузки новости</h5>
                    <p class="text-muted">Пожалуйста, попробуйте позже</p>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    🖨️ Печать
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.news-date-modal {
    background: #0033a0;
    color: white;
    padding: 8px 20px;
    border-radius: 25px;
    font-size: 0.95rem;
    font-weight: 600;
    white-space: nowrap;
}

.modal-news-image {
    width: 100%;
    max-height: 400px;
    object-fit: cover;
}

.modal-image-container {
    background: #f8f9fa;
    text-align: center;
}

.news-full-text {
    font-size: 1.05rem;
    line-height: 1.8;
    color: #444;
}

.modal-xl {
    max-width: 960px;
}

@media (max-width: 768px) {
    .modal-news-body {
        padding: 20px !important;
    }
    .news-full-text {
        font-size: 0.95rem;
    }
}
</style>

<script>
// Функция открытия новости в модальном окне
function openNews(newsId) {
    const modal = new bootstrap.Modal(document.getElementById('newsModal'));
    modal.show();
    
    // Показываем загрузку
    document.getElementById('modal-loading').style.display = 'block';
    document.getElementById('modal-content').style.display = 'none';
    document.getElementById('modal-error').style.display = 'none';
    
    // Загружаем данные новости через AJAX
    fetch('/admin/controllers/get_news.php?id=' + newsId)
        .then(response => response.json())
        .then(data => {
            document.getElementById('modal-loading').style.display = 'none';
            
            if (data.error) {
                document.getElementById('modal-error').style.display = 'block';
                return;
            }
            
            // Заполняем данные
            document.getElementById('modal-title').textContent = data.title;
            document.getElementById('modal-date').textContent = data.date_formatted;
            document.getElementById('modal-text').innerHTML = data.text_formatted;
            
            // Изображение
            const imgElement = document.getElementById('modal-image');
            const imgContainer = document.querySelector('.modal-image-container');
            
            if (data.image) {
                imgElement.src = '/assets/images/news/' + data.image;
                imgElement.style.display = 'block';
                imgContainer.style.display = 'block';
            } else {
                imgContainer.style.display = 'none';
            }
            
            document.getElementById('modal-content').style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('modal-loading').style.display = 'none';
            document.getElementById('modal-error').style.display = 'block';
        });
}
</script>

<?php 
require_once __DIR__ . '/includes/footer.php'; 
?>